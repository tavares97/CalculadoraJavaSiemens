package Calculadora;


public class Cenas {

    private double valor1;
    private double valor2;
    //variaveis para calculo Expoente
    private double base;
    private double temp;
    private double exp;
    //variaveis para calculo Factorial
    private double fact;
    //variaveis para converter N para Binario
    private int bin;

    public Cenas() {
        valor1 = 0;
        valor2 = 0;        
        base = 0;
        fact = 1; 
        bin = 0;
    }

    //definir valores
    public void setValor1(double valor1) {
        this.valor1 = valor1;
    }

    public void setValor2(double valor2) {
        this.valor2 = valor2;
    }
    
    public void setBase(double base) {
        this.base = base;
    }
    
    public void setExp(double exp) {
        this.exp = exp;
    }
    public void setBin(int bin) {
        this.bin = bin;
    }
    // Realiza a operação 
    public double Addition() {
        return valor1 + valor2;
    }

    public double Subtraction() {
        return valor1 - valor2;
    }

    public double Multiplication() {
        return valor1 * valor2;
    }

    public double Division() {
        return valor1 / valor2;
    }
    
    public double NumToThePower() {
        temp = base;
        
        for (int i=1 ; i < exp; i++) {
            temp = temp*temp;
        }
        
        return temp;
    }
    
    public double Factorial() {
        
        for (int i=1 ; i<=valor1; i++) {
            fact = fact*i;
        }
        
        return fact;
    }
    
    public int DecToBin() {
        return bin;
    }
}
