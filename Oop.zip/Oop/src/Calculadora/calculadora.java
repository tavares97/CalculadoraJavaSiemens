package Calculadora;

import java.util.Scanner;

public class calculadora {

    public static void main(String[] args) {
        
        Cenas contas = new Cenas();
        Scanner in = new Scanner(System.in);
        
          
        System.out.print("Inisira um valor: ");
        contas.setValor1(in.nextDouble());
        
        System.out.print("Insira outro valor: ");
        contas.setValor2(in.nextDouble());
        
        System.out.print("Insira a base: ");
        contas.setBase(in.nextDouble());
        
        System.out.print("Insira o expoente: ");
        contas.setExp(in.nextDouble());
        
        System.out.print("Insira um valor a converter para binario: ");
        contas.setBin(in.nextInt());
        
                         
        System.out.println("resultado :"+contas.Addition());
        System.out.println("resultado :"+contas.Subtraction());
        System.out.println("resultado :"+contas.Multiplication());
        System.out.println("resultado :"+contas.Division());
        System.out.println("resultado :"+contas.NumToThePower());
        System.out.println("resultado :"+contas.Factorial());
        System.out.println("resultado :"+Integer.toBinaryString(contas.DecToBin()));
    }
}
